package com.example.phototur;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    CardView btnMapa, btnCamera;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        verificarPermissoes();

        btnCamera = findViewById(R.id.btnCamera);
        btnMapa = findViewById(R.id.btnMapa);

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCamera();
            }
        });
        btnMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirMapa();
            }
        });

    }
    private void abrirMapa(){
        Intent janela = new Intent(this, TelaMapa.class);
        startActivity(janela);
        finish();
    }

    private void abrirCamera(){
        Intent janela = new Intent(this, TelaCamera.class);
        startActivity(janela);
        finish();
    }

    public static String getNomeArquivo(String prefixo, String extensao) throws IOException {
        File diretorio = new File(Environment.getExternalStorageDirectory() +
                File.separator + "DCIM" + File.separator + "QIAPP");
        diretorio.mkdirs();
        String datahora = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String nomeArquivo = prefixo + "_" + datahora + "." + extensao;
        return diretorio + File.separator + nomeArquivo;
    }

    private void verificarPermissoes(){
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                    }, 1);
        }
    }
}